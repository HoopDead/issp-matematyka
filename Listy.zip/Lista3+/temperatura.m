function temperatura(Tp, Tk)
C = [Tp:1:Tk]
C = C';
F = 9/5*C + 32