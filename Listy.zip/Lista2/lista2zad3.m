clear
quiver(0, 0, 5, 0, 1);
hold on
quiver(5, 0, 0, -3, 1);
quiver(5, -3, -2, 0, 1);
quiver(3, -3, 0, 1, 1);
quiver(0, 0, 3, -2, 1);
ans = sqrt((3^2 + (-2)^2))
text(2, -1, '3.6056, [3, -2]')