clear
a1 = 25 * cos(210 * pi / 180);
quiver(0, 0, a1, 0)
hold on
b1 = 25 * sin(210 * pi / 180);
quiver(0, 0, 0, b1)

quiver(0, 0, a1, b1)
hold off